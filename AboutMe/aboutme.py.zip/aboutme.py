print('My name is Dylan Motley')
print('I am from Troy, Missouri')
print('I like playing video games and learning about history in my free time')
print('I used Python in my first computer science class back in my softmore year of highschool')
